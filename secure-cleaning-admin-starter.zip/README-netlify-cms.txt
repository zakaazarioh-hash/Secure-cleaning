# Secure Cleaning — Admin (Netlify CMS) Starter

Dit pakket bevat alles om je site met **/admin** te beheren via Netlify CMS.

## Bestanden
- `index-admin-ready.html` → gebruik deze als je `index.html` (hij laadt content uit `content/site.json`)
- `content/site.json` → alle teksten die je via /admin kunt aanpassen
- `admin/index.html` + `admin/config.yml` → CMS login en configuratie
- `robots.txt` + `sitemap.xml` → voor SEO
- `banner-1200x630.png` + `favicon.ico`

## Stappen: GitHub → Netlify → Admin
1) **GitHub**
   - Maak een account op github.com (als je die nog niet hebt)
   - Maak een nieuwe repo (bijv. `secure-cleaning`)
   - Upload ALLE bestanden uit dit pakket
   - Hernoem `index-admin-ready.html` naar **`index.html`**

2) **Netlify**
   - Ga naar app.netlify.com → **Add new site → Import from Git**
   - Koppel je GitHub en kies de repo → Deploy
   - (Optioneel) Koppel je domein bij **Domain settings**

3) **Identity + Git Gateway**
   - In Netlify: **Site settings → Identity → Enable Identity**
   - **Registration**: kies *Invite only*
   - Klik **Invite users** en nodig je eigen e-mail uit
   - Ga naar **Identity → Services → Enable Git Gateway** (volg de GitHub-authorisatie)

4) **Inloggen**
   - Open `https://<jouw-site>.netlify.app/admin`
   - Accepteer de uitnodiging in je e-mail en log in
   - Je ziet 1 collectie: **Site-inhoud** → pas teksten aan en **Publish**

5) **Zoekmachines**
   - Zet je domein in `sitemap.xml` (vervang `https://secure-cleaning.nl` door jouw domein)
   - Voeg in `index.html` je **Google** en **Bing** verificatiecodes toe

Klaar! ✨
